import tkinter as tk
from tkinter import ttk
from operator import itemgetter

from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# Sample prices only, not live online prices (in Rs.)
PRODUCTS = {
    "Wireless Mouse":    {"Amazon": 599,  "Flipkart": 549,  "Meesho": 499},
    "Headphones":        {"Amazon": 1499, "Flipkart": 1399, "Meesho": 1299},
    "Keyboard":          {"Amazon": 899,  "Flipkart": 849,  "Meesho": 799},
    "Power Bank":        {"Amazon": 1199, "Flipkart": 1099, "Meesho": 999},
    "Smart Watch":       {"Amazon": 2499, "Flipkart": 2299, "Meesho": 2199},
    "USB-C Cable":       {"Amazon": 399,  "Flipkart": 349,  "Meesho": 299},
    "Webcam":            {"Amazon": 1799, "Flipkart": 1649, "Meesho": 1599},
    "Bluetooth Speaker": {"Amazon": 1999, "Flipkart": 1849, "Meesho": 1749},
}

# Colours
BG = "#e8f4fd"
HEADING = "#0d47a1"
GREEN = "#2e7d32"
RED = "#c62828"
PLATFORM_COLORS = {"Amazon": "#ff9900", "Flipkart": "#2874f0", "Meesho": "#9c27b0"}
DEFAULT_BAR_COLOR = "#607d8b"

graph_window = None  # only one graph window is kept open at a time


def refresh(product, sort=False):
    """Fill the table and summary labels for one product.

    One function serves both "Compare Again" and "Sort by Price", so the
    table, the cheapest-seller check and the saving are computed in one place.
    """
    prices = PRODUCTS[product]
    items = sorted(prices.items(), key=itemgetter(1)) if sort else list(prices.items())

    cheapest_app, lowest = min(items, key=itemgetter(1))  # O(n), no second pass
    highest = max(prices.values())
    difference = highest - lowest
    saving_pct = difference / highest * 100

    children = table.get_children()
    if children:
        table.delete(*children)
    for app, price in items:
        table.insert(
            "", "end",
            values=(app, f"Rs. {price:,}"),
            tags=("cheap" if app == cheapest_app else "normal",),
        )

    result.config(text=f"Cheapest: {cheapest_app} - Rs. {lowest:,}")
    saving.config(text=f"Price difference: Rs. {difference:,} ({saving_pct:.0f}% saving)")


def show_graph():
    global graph_window
    product = choice.get()
    prices = PRODUCTS[product]

    if graph_window is not None and graph_window.winfo_exists():
        graph_window.destroy()
    graph_window = tk.Toplevel(root)
    graph_window.title("Price Comparison Graph")
    graph_window.geometry("650x450")
    graph_window.configure(bg=BG)

    # Figure (not pyplot) avoids keeping a global figure open for every click
    figure = Figure(figsize=(6, 4), dpi=100)
    axis = figure.add_subplot(111)

    apps = list(prices)
    bars = axis.bar(apps, list(prices.values()),
                    color=[PLATFORM_COLORS.get(a, DEFAULT_BAR_COLOR) for a in apps])
    axis.bar_label(bars)
    axis.set_title(f"{product} Price Comparison", color=HEADING)
    axis.set_xlabel("Shopping Apps")
    axis.set_ylabel("Price in Rupees")
    figure.tight_layout()

    canvas = FigureCanvasTkAgg(figure, master=graph_window)
    canvas.draw()
    canvas.get_tk_widget().pack(fill="both", expand=True)


# ---------- Main window ----------
root = tk.Tk()
root.title("Online Price Analyzer")
root.geometry("650x560")
root.configure(bg=BG)

style = ttk.Style()
style.theme_use("clam")
style.configure("Treeview", background="white", fieldbackground="white",
                rowheight=30, font=("Arial", 11))
style.configure("Treeview.Heading", background=HEADING, foreground="white",
                font=("Arial", 12, "bold"))

tk.Label(root, text="ONLINE PRICE ANALYZER", font=("Arial", 20, "bold"),
         bg=HEADING, fg="white", width=30).pack(pady=15)
tk.Label(root, text="Select a product to compare its prices",
         font=("Arial", 11), bg=BG, fg="#333333").pack()

choice = ttk.Combobox(root, values=list(PRODUCTS), state="readonly", width=25)
choice.pack(pady=10)
choice.set(next(iter(PRODUCTS)))
choice.bind("<<ComboboxSelected>>", lambda e: refresh(choice.get()))

table = ttk.Treeview(root, columns=("app", "price"), show="headings", height=4)
table.heading("app", text="Shopping App")
table.heading("price", text="Price")
table.column("app", width=250, anchor="center")
table.column("price", width=250, anchor="center")
table.tag_configure("cheap", background="#c8e6c9", foreground="#1b5e20")
table.tag_configure("normal", background="#fff9c4", foreground="black")
table.pack(pady=10)

result = tk.Label(root, text="", font=("Arial", 12, "bold"), bg=BG, fg=GREEN)
result.pack(pady=5)
saving = tk.Label(root, text="", font=("Arial", 11), bg=BG, fg=RED)
saving.pack(pady=3)

buttons = tk.Frame(root, bg=BG)
buttons.pack(pady=15)
actions = [
    ("Sort by Price", lambda: refresh(choice.get(), sort=True), "#ff9800"),
    ("Show Graph", show_graph, "#4caf50"),
    ("Compare Again", lambda: refresh(choice.get()), "#2196f3"),
]
for col, (text, command, color) in enumerate(actions):
    tk.Button(buttons, text=text, command=command, bg=color, fg="white",
              font=("Arial", 11, "bold"), width=14).grid(row=0, column=col, padx=5)

refresh(choice.get())
root.mainloop()